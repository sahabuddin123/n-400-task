
<?php
	$id = 1;
	if(isset($fatch)){
		$id = $fatch;
	}
?>

<button><a href="<?php echo e(route('question.show',$id)); ?>">Click Me</a></button><?php /**PATH D:\laravelproject\wiztechnology\resources\views/question/show.blade.php ENDPATH**/ ?>