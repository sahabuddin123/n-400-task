<!DOCTYPE html>
<html lang="en">
<head>
    <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e(config('app.name')); ?></title>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/css/main.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/css/font-awesome/4.7.0/css/font-awesome.min.css')); ?>"/>
    <link href="<?php echo e(asset('backend/plugins/smartwizard/css/smart_wizard.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('backend/plugins/smartwizard/css/smart_wizard_theme_arrows.css')); ?>" rel="stylesheet" type="text/css" />

    <!-- Optional SmartWizard theme -->

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <!-- <style>
        #phase2, #phase3, #phase4 {
         display:none; 
     }
    </style> -->
</head>
<body class="app sidebar-mini rtl">
    <?php echo $__env->make('question.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('question.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="app-content" id="app">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <script src="<?php echo e(asset('backend/js/jquery-3.2.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/plugins/pace.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/plugins/smartwizard/js/jquery.smartWizard.min.js')); ?>"></script>


    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH D:\laravelproject\wiztechnology\resources\views/question/app.blade.php ENDPATH**/ ?>