

<button><a href="{{route('question.show')}}">Click Me</a></button>